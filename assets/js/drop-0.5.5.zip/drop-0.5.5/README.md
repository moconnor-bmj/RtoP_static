## Drop

Drop.js is a powerful Javascript and CSS library for creating dropdowns and other floating displays.

[![Drop Docs](http://i.imgur.com/sgmx9aJ.png)](http://github.hubspot.com/drop/)

### [Demo](http://github.hubspot.com/drop/docs/welcome) &nbsp;&nbsp; [Documentation](http://github.hubspot.com/drop)
